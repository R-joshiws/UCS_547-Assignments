import cupy as cp
import time

N = 5_000_000

A = cp.arange(N, dtype=cp.float32)
B = 2 * A

C = A + B
cp.cuda.Stream.null.synchronize()

start = time.time()
C = A + B
cp.cuda.Stream.null.synchronize()
end = time.time()

print("Time:", (end - start) * 1000, "ms")

print("C[0] =", C[0].item(), ", C[N-1] =", C[-1].item())
