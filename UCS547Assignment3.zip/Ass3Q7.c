#include <thrust/device_vector.h>
#include <thrust/sort.h>
#include <iostream>

int main() {
    int h[] = {7, 2, 9, 1, 5, 3, 8, 4};

    thrust::device_vector<int> v(h, h + 8);

    std::cout << "Before:";
    for (int i = 0; i < v.size(); i++)
        std::cout << v[i] << " ";
    std::cout << std::endl;

    thrust::sort(v.begin(), v.end());

    std::cout << "After:";
    for (int i = 0; i < v.size(); i++)
        std::cout << v[i] << " ";
    std::cout << std::endl;

    return 0;
}
