#include <thrust/device_vector.h>
#include <thrust/transform.h>
#include <iostream>

int main() {
    const int N = 1024;

    thrust::device_vector<float> A(N), B(N), C(N);

    thrust::sequence(A.begin(), A.end(), 0);
    thrust::sequence(B.begin(), B.end(), 0, 2);

    thrust::transform(A.begin(), A.end(),
                      B.begin(),
                      C.begin(),
                      thrust::plus<float>());

    std::cout << "C[0] = " << C[0]
              << ", C[1023] = " << C[1023] << std::endl;

    return 0;
}
