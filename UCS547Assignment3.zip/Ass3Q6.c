#include <thrust/device_vector.h>
#include <thrust/reduce.h>
#include <iostream>

int main() {
    thrust::device_vector<int> v(10);
    thrust::sequence(v.begin(), v.end(), 1);

    int sum = thrust::reduce(v.begin(), v.end(), 0, thrust::plus<int>());

    std::cout << "Sum = " << sum << std::endl;
    return 0;
}
