#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 1024

int main() {
    float *A = (float*)malloc(N * sizeof(float));
    float *B = (float*)malloc(N * sizeof(float));

    for (int i = 0; i < N; i++) {
        A[i] = i + 1;
        B[i] = 2 * (i + 1);
    }

    clock_t start = clock();

    float result = 0.0f;
    for (int i = 0; i < N; i++)
        result += A[i] * B[i];

    clock_t end = clock();

    double time_taken = (double)(end - start) / CLOCKS_PER_SEC;

    printf("DotPro = %.2f\n", result);
    printf("ExecTime = %f seconds\n", time_taken);

    free(A);
    free(B);

    return 0;
}
