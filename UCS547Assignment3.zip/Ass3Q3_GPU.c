#include <thrust/device_vector.h>
#include <thrust/inner_product.h>
#include <thrust/sequence.h>
#include <stdio.h>
#include <cuda_runtime.h>

#define N 1024

int main() {
    thrust::device_vector<float> A(N), B(N);

    thrust::sequence(A.begin(), A.end(), 1);
    thrust::sequence(B.begin(), B.end(), 2, 2);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);

    float result = thrust::inner_product(A.begin(), A.end(),
                                         B.begin(), 0.0f);

    cudaEventRecord(stop);
    cudaEventSynchronize(stop);

    float milliseconds = 0;
    cudaEventElapsedTime(&milliseconds, start, stop);

    printf("DotPro = %.2f\n", result);
    printf("ExecTime = %f ms\n", milliseconds);

    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}
