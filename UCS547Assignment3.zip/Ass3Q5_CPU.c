// q5_cpu_vector_add.cu
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 5000000

int main() {
    float *A = (float*)malloc(N * sizeof(float));
    float *B = (float*)malloc(N * sizeof(float));
    float *C = (float*)malloc(N * sizeof(float));

    for (int i = 0; i < N; i++) {
        A[i] = i;
        B[i] = 2 * i;
    }

    clock_t start = clock();

    for (int i = 0; i < N; i++)
        C[i] = A[i] + B[i];

    clock_t end = clock();

    double time_taken = (double)(end - start) / CLOCKS_PER_SEC;

    printf("Time = %f seconds\n", time_taken);

    free(A); free(B); free(C);
    return 0;
}
